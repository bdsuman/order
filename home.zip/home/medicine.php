<?php

session_start();
if(!isset( $_SESSION['myusername'] ))
{
    header("location:login.php");
}

?>
<?php
ob_start();
require_once "config.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>.::AnandasoftBD::.</title> 
<link rel="stylesheet" type="text/css" href="css/body.css" />
<link rel="stylesheet" href="css/buttonstyles.css">
<script src="jquery.js"></script>
<script type="text/javascript">
        $(document).ready(function(){
            $("select#products").attr("disabled","disabled");
            $("select#company").change(function(){
            $("select#products").attr("disabled","disabled");
            $("select#products").html("<option>wait...</option>");
            var id = $("select#company option:selected").attr('value');
            $.post("select_company.php", {id:id}, function(data){
                $("select#products").removeAttr("disabled");
                $("select#products").html(data);
            });
        });
        $("form#select_form").submit(function(){
            var cat = $("select#company option:selected").attr('value');
            var products = $("select#products option:selected").attr('value');
            if(cat>0 && products>0)
            {
                var result = $("select#products option:selected").html();
                $("#result").html('your choice: '+result);
            }
            else
            {
                $("#result").html("you must choose two options!");
            }
            return false;
        });
    });
    </script>
		<script>
			function showEdit(editableObj) {
				$(editableObj).css("background","#FFF");
			}
			
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'medicine'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
		
</head>
<body>
    <div id="wrapper">
       <?php
	$_GET['nav']='order';
	include "head.php";
	include "leftmenu.php";
	
	date_default_timezone_set('Asia/Dacca');
		$date = date('Y-m-d', time());
	$result2 = mysqli_query($con,"SELECT max(id) as inv FROM medicine");
			if($rows = mysqli_fetch_array($result2)){ 
				if($rows['inv']>0){
					$m_sn=$rows['inv']+1;
				} else {
					$m_sn=date("y"). date('m').date('d')."001";
				}
			} else { 
				$m_sn=date("y"). date('m').date('d')."001";
			}
		
		
	?>
         <div align="center" id="content">
		 <div class="CSSTableGenerator">
           <form action="" method="POST">
			<table  align="center">
				<tr>
					<td colspan="9" align="center"><span style="color:#FFFFFF; font:24px sans-serif;"><strong>Medicine Info</strong></span></td>
				</tr>
				
				<tr>
					<td   align="right">ID:</td>
					<td  ><input type="text" name="" value="<?php echo $m_sn;?>" readonly>	</td>
				</tr>
				<tr>
					<td   align="right">Medicine :</td>
					<td  ><textarea name="name" required placeholder="Napa Extend 665 mg Tab"></textarea></td>
				</tr>				
				<tr >
					<td ></td>

				   <td  ><input type="submit" class="myButton" name="submit" value="Submit" /></td>

				</tr>
				</table>

				</form>


<?php
if(isset($_POST['submit'])) {
	

	$sql="INSERT INTO `medicine`(`id`,`m_name`) VALUES (NULL,'$_POST[m_name]')";
 	
	if (!mysqli_query($con,$sql))
  {
  die('Error:INSERT INTO `medicine` ' . mysqli_error($con));
  }     
	echo '<script type="text/javascript">alert("Successfully Inserted.");window.close();</script>';

}
if(isset($_POST['delete'])) {
mysqli_query($con,"DELETE FROM `medicine` WHERE id='$_POST[id]'");

echo '<script type="text/javascript">alert("Deleted Successfully.");window.close();</script>';

}
?>
<?php
$i=1;
	$result3 = mysqli_query($con,"SELECT * FROM `medicine` order by `id`");
	?>
		<table align="center" width="800" border="1" >
			<tr>
				<td>Serial</td>
				<td>Medicine</td>
				<td>Action</td>
			</tr>
	<?php
	while($row = mysqli_fetch_array($result3))
		{
		?>
		<tr>
			<td align="center" contenteditable="false" onBlur="saveToDatabase(this,'id','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $i++?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'m_name','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['m_name']; ?></td>
			<form action="" method="post">
			<td align="center">
				<input name="id" type="hidden" value="<?php echo $row['id'];?>">
				<button type="submit" name="delete" class="btn btn-danger">
					<i class="icon-trash" aria-hidden="true"></i> Delete
				</button>
				
			</td>
			</form>	
		</tr>
		<?php
			
		}
		mysqli_close($con);
		?>
		
</table>
</div>
       </div>
        <?php
	include "footer.php"
	?>
    </div>
</body>
</html>
