<?php

session_start();
if(!isset( $_SESSION['myusername'] ))
{
    header("location:login.php");
}

?>
<?php
ob_start();
require_once "config.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>.::AnandasoftBD::.</title> 
<link rel="stylesheet" type="text/css" href="css/body.css" />
<link rel="stylesheet" href="css/buttonstyles.css">
<script src="jquery.js"></script>
<script type="text/javascript">
        $(document).ready(function(){
            $("select#products").attr("disabled","disabled");
            $("select#company").change(function(){
            $("select#products").attr("disabled","disabled");
            $("select#products").html("<option>wait...</option>");
            var id = $("select#company option:selected").attr('value');
            $.post("select_company.php", {id:id}, function(data){
                $("select#products").removeAttr("disabled");
                $("select#products").html(data);
            });
        });
        $("form#select_form").submit(function(){
            var cat = $("select#company option:selected").attr('value');
            var products = $("select#products option:selected").attr('value');
            if(cat>0 && products>0)
            {
                var result = $("select#products option:selected").html();
                $("#result").html('your choice: '+result);
            }
            else
            {
                $("#result").html("you must choose two options!");
            }
            return false;
        });
    });
    </script>
		<script>
			function showEdit(editableObj) {
				$(editableObj).css("background","#FFF");
			}
			
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'pharmacy'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
		
</head>
<body>
    <div id="wrapper">
       <?php
	$_GET['nav']='order';
	include "head.php";
	include "leftmenu.php";
	
	date_default_timezone_set('Asia/Dacca');
		$date = date('Y-m-d', time());
	$result2 = mysqli_query($con,"SELECT max(pharmacy_id) as inv FROM pharmacy where p_date='$date'");
			if($rows = mysqli_fetch_array($result2)){ 
				if($rows['inv']>0){
					$p_sn=$rows['inv']+1;
				} else {
					$p_sn=date("y"). date('m').date('d')."001";
				}
			} else { 
				$p_sn=date("y"). date('m').date('d')."001";
			}
		
		
	?>
         <div align="center" id="content">
		 <div class="CSSTableGenerator">
           <form action="" method="POST">
			<table  align="center">
				<tr>
					<td colspan="9" align="center"><span style="color:#FFFFFF; font:24px sans-serif;"><strong>Pharmacy Info</strong></span></td>
				</tr>
				
				<tr>
					<td   align="right">Pharmacy ID:</td>
					<td  ><input type="text" name="pharmacy_id" value="<?php echo $p_sn;?>" readonly>	</td>
				</tr>
				<tr>
					<td   align="right">Pharmacy Name:</td>
					<td  ><input type="text" name="name" required></td>
				</tr>
				<tr>
					<td   align="right">Proprietor:</td>
					<td ><input type="text" name="proprietor"></td>
				</tr>
				<tr>
					<td   align="right">Address:</td>
					<td  ><input type="text" name="address" required></td>
				</tr>
				<tr>
					<td   align="right">Mobile:</td>
					<td  ><input type="text" name="mobile" required ></td>
				</tr>
				<tr>
					<td   align="right">Email:</td>
					<td  ><input type="email" name="email" required></td>
				</tr>
								
				<tr >
					<td ></td>

				   <td  ><input type="submit" class="myButton" name="submit" value="Submit" /></td>

				</tr>
				</table>

				</form>


<?php
if(isset($_POST['submit'])) {
	

	$sql="INSERT INTO `pharmacy`(`id`, `p_date`, `pharmacy_id`, `name`, `proprietor`, `address`, `mobile`, `email`) VALUES (NULL,'$date','$p_sn','$_POST[name]','$_POST[proprietor]','$_POST[address]','$_POST[mobile]','$_POST[email]')";
 	
	if (!mysqli_query($con,$sql))
  {
  die('Error:INSERT INTO pharmacy ' . mysqli_error($con));
  }     
	echo '<script type="text/javascript">alert("Successfully Inserted.");window.close();</script>';

}
if(isset($_POST['delete'])) {
mysqli_query($con,"DELETE FROM pharmacy WHERE id='$_POST[id]'");

echo '<script type="text/javascript">alert("Deleted Successfully.");window.close();</script>';

}
?>
<?php

	$result3 = mysqli_query($con,"SELECT * FROM pharmacy order by pharmacy_id");
	?>
		<table align="center" width="800" border="1" >
			<tr>
				<td>ID</td>
				<td>Pharmacy Name</td>
				<td>Proprietor</td>
				<td>Address</td>
				<td>Mobile</td>
				<td>Email</td>
				<td>Action</td>
			</tr>
	<?php
	while($row = mysqli_fetch_array($result3))
		{
		?>
		<tr>
			<td align="center" contenteditable="false" onBlur="saveToDatabase(this,'pharmacy_id','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['pharmacy_id']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'name','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['name']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'proprietor','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['proprietor']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'address','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['address']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'mobile','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['mobile']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'email','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['email']; ?></td>
			
			
			<form action="" method="post">
			<td align="center">
				<input name="id" type="hidden" value="<?php echo $row['id'];?>">
				
			
				<button type="submit" name="delete" class="btn btn-danger">
					<i class="icon-trash" aria-hidden="true"></i> Delete
				</button>
				
			</td>
			</form>	
		</tr>
		<?php
			
		}
		mysqli_close($con);
		?>
		
</table>
</div>
       </div>
        <?php
	include "footer.php"
	?>
    </div>
</body>
</html>
