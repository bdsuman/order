<?php
require_once "config.php";
$val=str_replace("<br>","",$_POST["editval"]); 
$val=trim(strip_tags($val));
echo "UPDATE " . $_POST["table"] . " set " . $_POST["column"] . " = '".$val."' WHERE  ID=".$_POST["ID"];
$result = mysqli_query($con,"UPDATE " . $_POST["table"] . " set " . $_POST["column"] . " = '".$val."' WHERE  ID=".$_POST["ID"]);
?>