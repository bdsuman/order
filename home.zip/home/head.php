<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<head>
<title>.::AnandasoftBD::.</title> 
	<link rel="stylesheet" type="text/css" href="css/tcal.css" />
	<script type="text/javascript" src="js/tcal.js"></script> 

	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="stylesheet" href="css/font-awesome.css"/>
  <link rel="stylesheet" href="css/font-awesome.min.css"/>


<link rel="stylesheet" type="text/css" href="css/body.css" />
<link rel="stylesheet" href="css/buttonstyles.css">

<script type="text/javascript" src="jquery.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
</head>
<div class="header"  >
<div class="col-md-12" align="center">
<div class="col-md-4" ><img src="img/logo.jpg" class="img-thumbnail" alt="Company Logo" width="100" height="70" style="margin-top: 5px; margin-bottom: 5px;" align="center" />    </div>
    <div class="col-md-4" align="center" style="margin-top: 20px; margin-bottom: 5px;"><span style="font-size:20pt;">BORO DAKTER</span></div>
    <div class="col-md-4" style="margin-top: 30px; margin-bottom: 5px;">
			<?php date_default_timezone_set('Asia/Dhaka');
				$date = date('l jS F Y', time()); 
				echo "Today is :<strong>&nbsp;".$date."</strong>"; ?>	
<br>
					Hello,&nbsp;<strong><?php echo $_SESSION["myusername"]; ?></strong>.&nbsp;(<a href="logout.php">Logout</a>)
								
	</div>
</div>
</div>
<div class="col-md-12" align="center">
<div id="nav">
	<ul>
		<li><a href="index.php"><span>Home</span></a></li>
		<li><a href="index.php?nav=order">Order</a></li>
		<li><a href="index.php?nav=reports">Reports</a></li>
		

	</ul>
</div>
</div>