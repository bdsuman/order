<!DOCTYPE html>
 <html lang="en" class="no-js"> 
    <head>
        <meta charset="UTF-8" />
        <title>log in</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
		<link rel="stylesheet" type="text/css" href="css/LoginCSS.css">
		<style>
			hr.style1 { 
			  border: 0; 
			  height: 1px; 
			  background-image: -webkit-linear-gradient(left, #1ABC9C, #76D7C4, #48C9B0);
			  background-image: -moz-linear-gradient(left, #1ABC9C, #76D7C4, #48C9B0);
			  background-image: -ms-linear-gradient(left, #1ABC9C, #76D7C4, #48C9B0);
			  background-image: -o-linear-gradient(left, #1ABC9C, #76D7C4, #48C9B0); 
			}

			footer {
				position:absolute;
				bottom:30px;
				width:100%;
				text-align:center;
			}
		</style>	
    </head>
    <body>
	
		<div class="wrapper">
		<!--<img src="img/path.png" height="250px" width="250px" alt="Image"  style="float: left;vertical-align: middle;position:absolute;top: 10px;right: 10px;" > -->
		<img src="img/blue-health.png" width="25%" alt="Image"  style="float: left;vertical-align: middle;position:absolute;top: 100px;left: 100px;" >
		<img src="img/bubbles.png" width="45%" alt="Image"  style="float: left;vertical-align: middle;position:absolute;bottom:70px;right: 0px;" >
			<div class="container">
				
				<span style="font-family:Calibri; font-size:22pt;font-weight:bold; color: white">Welcome to PMS</span>
				<hr class="style1">
				<form name="form1" method="post" action="checklogin.php">
					<input type="text" name="myusername" id="myusername" placeholder="Username">
					<input type="password" name="mypassword" id="mypassword" placeholder="Password">
					<input type="submit" id="login-button" value="Login">
				</form>
				<br>
				<br>
				<font color="red" >** </font><b> Restricted Area. Only For Official Staff.</b>
			</div>
			
			<ul class="bg-bubbles">
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
				<li></li>
			</ul>
			
		</div>
		<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
		<br>
		<br>
	<footer>
			<span style="font-size:12pt;font-weight:bold;">Software By: AnandaSOFT, Mymensingh.<br><a href="http://www.anandasoftbd.com">www.anandasoftbd.com</a>, Mobile: 01715 104 528</span>
	</footer>

    </body>
	
</html>
