<?php

session_start();
if(!isset( $_SESSION['myusername'] ))
{
    header("location:login.php");
}

?>
<?php
ob_start();
require_once "config.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>.::AnandasoftBD::.</title> 
<link rel="stylesheet" type="text/css" href="css/body.css" />
<link rel="stylesheet" href="css/buttonstyles.css">
<script src="jquery.js"></script>
<script type="text/javascript">
        $(document).ready(function(){
            $("select#products").attr("disabled","disabled");
            $("select#company").change(function(){
            $("select#products").attr("disabled","disabled");
            $("select#products").html("<option>wait...</option>");
            var id = $("select#company option:selected").attr('value');
            $.post("select_company.php", {id:id}, function(data){
                $("select#products").removeAttr("disabled");
                $("select#products").html(data);
            });
        });
        $("form#select_form").submit(function(){
            var cat = $("select#company option:selected").attr('value');
            var products = $("select#products option:selected").attr('value');
            if(cat>0 && products>0)
            {
                var result = $("select#products option:selected").html();
                $("#result").html('your choice: '+result);
            }
            else
            {
                $("#result").html("you must choose two options!");
            }
            return false;
        });
    });
    </script>
		<script>
			function showEdit(editableObj) {
				$(editableObj).css("background","#FFF");
			}
			
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'patient_info'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
		
</head>
<body>
    <div id="wrapper">
       <?php
	$_GET['nav']='hospital';
	include "head.php";
	include "leftmenu.php";
	include "select.class.php";	
	
	$result2 = mysql_query("SELECT max(p_id) as inv FROM patient_info");
	if($num_rows = mysql_fetch_array($result2))
		{
			$sn=$num_rows['inv']+1;
		} else {
			$sn=1;
		}
	
	?>
         <div align="center" id="content">
		 <div class="CSSTableGenerator">
           <form action="" method="POST">
			<table  align="center">
				<tr>
					<td colspan="9" align="center"><span style="color:#FFFFFF; font:24px sans-serif;"><strong>Patient Info</strong></span></td>
				</tr>
				<tr>
					<td   align="right">Date:</td>
					<td  >
					<?php date_default_timezone_set('Asia/Dacca'); 
					$date1 = date('Y-m-d', time());	?>
						<input type="text" name="date" value="<?php echo $date1;?>" class="tcal" ></td>
				</tr>
				<tr>
					<td   align="right">Patient ID:</td>
					<td  ><input type="text" name="p_id" value="<?php echo $sn;?>">	</td>
				</tr>
				<tr>
					<td   align="right">Patient Name:</td>
					<td  ><input type="text" name="p_name"></td>
				</tr>
				<tr>
					<td  align="right">Father's Name:</td>
					<td  ><input type="text" name="father"></td>
				</tr>

				<tr>
					<td  align="right">Husband's Name:</td>
					<td  ><input type="text" name="husband"></td>
				</tr>
				<tr>
					<td  align="right">Age:</td>
					<td  ><input type="text" name="age">
					</td>
				</tr>
				<tr>
					<td  align="right">Sex:</td>
					<td  >
						<select name="sex" >
							<option name="sex" value="">--select one--</option>
							<option name="sex" value="male">Male</option>
							<option name="sex" value="female">Female</option>
							<option name="sex" value="other">Other</option>
						</select>
					</td>
				</tr>
				<tr>		
					<td  valign="top" align="right">Address:</td>
					<td  ><textarea input="text" name="address" cols="30"></textarea>	</td>
				</tr>
				<tr>		
					<td  align="right">Phone:</td>
					<td  align="left"><input type="text" name="phone"></td> 
				</tr>
 
				<tr>
					<td  align="right">Advance:</td>
					<td  ><input type="text" name="advance"></td>
				</tr>
				<tr>
					<td  align="right">SL No:</td>
					<td  ><input type="text" name="sl_no"></td>
				</tr>
				<tr >
					<td ></td>

				   <td  ><input type="submit" class="myButton" name="submit" value="Submit" /></td>

				</tr>
				</table>

				</form>


<?php
if(isset($_POST['submit'])) {
	

	$sql="INSERT INTO patient_info  (e_date,p_id,p_name,father,husband,age,sex,address,phone) VALUES ('$_POST[date]','$sn','$_POST[p_name]','$_POST[father]','$_POST[husband]','$_POST[age]','$_POST[sex]','$_POST[address]','$_POST[phone]')";
 	
	if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }     
	echo '<script type="text/javascript">alert("Successfully Updated.");window.close();</script>';

}
if(isset($_POST['delete'])) {
mysql_query("DELETE FROM patient_info WHERE id='$_POST[id]'");

echo '<script type="text/javascript">alert("Deleted Successfully.");window.close();</script>';

}
?>
<?php

	$result3 = mysql_query("SELECT * FROM patient_info order by p_id");
	?>
		<table align="center" width="800" border="1" >
			<tr>
				<td>PID</td>
				<td>Patient Name</td>
				<td>Father's Name</td>
				<td>Husband Name</td>
				<td>Age</td>
				<td>Sex</td>
				<td>Address</td>
				<td>Phone</td>
		
			</tr>
	<?php
	while($row = mysql_fetch_array($result3))
		{
		?>
		<tr>
			<td contenteditable="false" onBlur="saveToDatabase(this,'p_id','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['p_id']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'p_name','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['p_name']; ?></td>
			<td align="right" contenteditable="true" onBlur="saveToDatabase(this,'father','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['father']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'husband','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['husband']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'age','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['age']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'sex','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['sex']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'address','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['address']; ?></td>
			<td align="left" contenteditable="true" onBlur="saveToDatabase(this,'phone','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['phone']; ?></td>
			<form action="" method="post">
			<td align="center">
				<input name="id" type="hidden" value="<?php echo $row['id'];?>">
				
			
				<button type="submit" name="delete" class="btn btn-danger">
					<i class="icon-trash" aria-hidden="true"></i> Delete
				</button>
				
			</td>
			</form>		
		</tr>
		<?php
			
		}
		mysql_close($con);
		?>
		
</table>
</div>
       </div>
        <?php
	include "footer.php"
	?>
    </div>
</body>
</html>
