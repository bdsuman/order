<?php 
session_start();
session_destroy();
echo '<script type="text/javascript">alert("You have successfully Logout.");window.location=\'login.php\';</script>';
?>

