<?php

session_start();
if(!isset( $_SESSION['myusername'] ))
{
    header("location:login.php");
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Ananda Multimedia Business System</title>
<link rel="stylesheet" type="text/css" href="css/tcal.css" />
<script type="text/javascript" src="js/tcal.js"></script> 
<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/body.css" />
<link rel="stylesheet" href="css/buttonstyles.css">
<script src="jquery.js"></script>

<script type="text/javascript">
	function showEdit(editableObj) {
			$(editableObj).css("background","#FFF");
		}
	function saveToDatabase(editableObj,column,ID) {
		$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
		$.ajax({
			url: "AllEdit.php",
			type: "POST",
			data:'table='+'member'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
			success: function(data){
				$(editableObj).css("background","#F7F799");					
				//alert(data);
			
				}        
		   });
		   
		}
		</script>
</head>
<body>
    <div id="wrapper">
       <?php
			$_GET['nav']='hospital'; 
			include "config.php";
			include "head.php";
			include "leftmenu.php";
			
			$res1=mysqli_query($con,"SELECT * from member where username='$_SESSION[myusername]'");
			if($row1=mysqli_fetch_array($res1))
			if($row1['type']!='ADMIN')
				exit ;
		?>
         
		 <div align="center" id="content">
		 <div class="CSSTableGenerator">
           
		  
<form action="" method="POST">
	<table bordercolor="#999999" border="0" align="center">
		<tr>
			<td colspan="9" align="center"><span style="color:#FFFFFF; font:24px sans-serif;"><strong>Manage Users</strong></span></td>
		</tr>
		<tr>
			<td>Username</td>
			<td><input type="text" name="username"  placeholder="username" required></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="text" name="password"  placeholder="password" required></td>
		</tr>
		<tr>
			<td>Full Name</td>
			<td><input type="text" name="fullname"  placeholder="Full Name" required></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="email"   placeholder="Email" ></td>
		</tr>
		<tr>
			<td>Mobile</td>
			<td><input type="text" name="mobile"  placeholder="11 digit mobile no" maxlength="11" ></td>
		</tr>
		<tr>
			<td>User Type</td>
			<td><select name="type" required>
				<option value="">--Select User Type--</option>
				<option value="ADMIN">ADMIN</option>
				<option value="MANAGER">MANAGER</option>
			  </select>
			 </td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Create User"> </td>
			
		</tr>
	</table>

			
		</form>
<?php
if(isset($_POST['del'])){
		mysqli_query($con,"DELETE FROM member where id='$_POST[id]'");
		echo '<script type="text/javascript">alert("User deleted.");</script>';
	}
	
if(isset($_POST['submit'])){
			
		//$password = sprintf('%06d', mt_rand(0,99999999));
		
		mysqli_query($con,"INSERT INTO member (`username`, `password`, `fullname`,`email`,`mobile`, `type`) VALUES('$_POST[username]','$_POST[password]','$_POST[fullname]','$_POST[email]','$_POST[mobile]','$_POST[type]')");

		echo '<script type="text/javascript">alert("New User Created Successfully.");</script>';
}

	
	$res=mysqli_query($con,"SELECT * from member order by username");
	$u_num=mysqli_num_rows($res);
?>	
	<table align="center" width="800" border="1" >
		<tr>
			<td>SN</td>
			<td>Username</td>
			<td>Password</td>
			<td>Name</td>
			<td>Email</td>
			<td>Mobile</td>
			<td>Type</td>
			<td>Action</td>
		</tr>
<?php
		$sn=1;
		while($row = mysqli_fetch_array($res)){
?>		

		<tr>
			<td><?php echo $sn++;?></td>
		
			<td align="center" contenteditable="true" onBlur="saveToDatabase(this,'username','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['username']; ?></td>
			<td align="center" contenteditable="true" onBlur="saveToDatabase(this,'password','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['password']; ?></td>
			<td align="center" contenteditable="true" onBlur="saveToDatabase(this,'fullname','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['fullname']; ?></td>
			<td align="center" contenteditable="true" onBlur="saveToDatabase(this,'email','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['email']; ?></td>
			<td align="center" contenteditable="true" onBlur="saveToDatabase(this,'mobile','<?php echo $row['id']; ?>')" onClick="showEdit(this);"><?php echo $row['mobile']; ?></td>
			
			<td><?php echo $row['type'];?></td>
			<form action="" method="POST">
			<td>	
				<input type="hidden" name="id" value="<?php echo $row['id'];?>">
				
				<input type="submit" name="del" value="Del">
			</td>
			</form>
		</tr>
	
	
	<?php
	}
	?>
	
	</table>



		
		   
       </div>
        
    </div>
	<?php 
	mysqli_close($con);
	include "footer.php";?>
	</div>
</body>
</html>
