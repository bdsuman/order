<?php

session_start();
if(!isset( $_SESSION['myusername'] ))
{
    header("location:login.php");
}

?>
<?php
ob_start();

if(!class_exists('PHPMailer')) {
    require('phpmailer/class.phpmailer.php');
    require('phpmailer/class.smtp.php');
}
	error_reporting(E_STRICT | E_ALL);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<title>.::AnandasoftBD::.</title> 
	<link rel="stylesheet" type="text/css" href="css/body.css" />
	<link rel="stylesheet" href="css/buttonstyles.css">
	<script src="jquery.js"></script>

	
</head>
<body>
    <div id="wrapper">
		<?php
			$_GET['nav']='order';  
			include "config.php";
			include "head.php";
			include "leftmenu.php";
			
			date_default_timezone_set('Asia/Dacca');
			$date = date('Y-m-d', time());
			$time=date("Y-m-d H:i:s",time());
		?>
        <div align="center" id="content">
			<div class="CSSTableGenerator" >
		 
				<form action="" method="post" name="form1">
					<table border="0" align="center">
						<tr>
							<td colspan="9" align="center">
								<span style="color:#FFFFFF; font:24px sans-serif;"><strong>Order Confirm</strong></span>
							</td>
						</tr>
						<tr>
							<td align="right">Select Date :</td>
							<td>
								<input type="text" name="from_date" class="tcal" value="<?php echo $date; ?>" /> -  <input type="text" name="to_date" class="tcal" value="<?php echo $date; ?>" /> &nbsp;&nbsp;&nbsp;&nbsp;
								<label>Confirm</label>
								<select name="confirm">
									<option value="">Select</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>&nbsp;&nbsp;&nbsp;&nbsp;
								<input type="submit" class="myButton" name="submit" value="Submit" />
							</td>
						</tr>
						<tr>
							<td align="right">&nbsp;</td>
							<td  ></td>
						</tr>
					</table>
				</form>
<?php

	if(isset($_POST['yes'])){
		
			
			
			$str="UPDATE `sale_details` SET `confirm`='Yes',`confirm_date`='$date' where `sale_no`='$_POST[sale_no]'";
			//echo $str;
			 if(!mysqli_query($con,$str)){
							die('Error: UPDATE `sale_details` Fail.'.mysqli_error($con));
						}
			
			$order=$_POST['sale_no'];
			$pieces = explode("-", $_POST["pharmacy"]);//split the ID text
			$name=$pieces[0];
			$pharmacy=$pieces[1];
			$p = explode(",", $pharmacy);
			$pharmacy_id=$p[0];
			
			$re = mysqli_query($con,"SELECT * FROM `pharmacy` WHERE `pharmacy_id`='$pharmacy_id'");
			while($row2 = mysqli_fetch_array($re)){
				 
				$mobile=$row2['mobile'];
				$email=$row2['email'];
			}
			
			// Email Send Start
							$mail = new PHPMailer();
							$mail->IsSMTP(); 
							$mail->CharSet="UTF-8";
							$mail->Host = "mail.borodakter.info";
							$mail->SMTPDebug = 0; 
							$mail->Port = 465 ; //465 or 587
							$mail->SMTPSecure = 'ssl';  
							$mail->SMTPAuth = true; 
							//Authentication
							$mail->Username = "noreply@borodakter.info";
							$mail->Password = "suman2020";
							$mail->setFrom('noreply@borodakter.info', 'BORO DAKTER');
							$mail->Subject = "New :: Order";
							$body="Dear " .$name. ",<br><br>".
								"Your new Order No:".$order."<br><br>".
								"See Invoice Click here <a href= 'http://www.borodakter.info/order/invoice_process.php?sale_no=".$order."' target='_blank'> Invoice </a><br><br>".
								"Kind Regards,<br>AnandasoftBD,Mymensingh<br>".
								"Please don't reply to this email.";
							$mail->msgHTML($body);
							$mail->AltBody = 'Message from BORO DAKTER';
							$mail->addAddress($email);
							$mail->send();
			// Email Send End			
			//SMSM
			//EMAIL
			// send sms start
							$SMS = "Boro Dakter: Dear " . $name . ", Your New Order ID:".$order.". See the invoice please check your email. THANK YOU";
								
							try {
									$soapClient = new SoapClient("http://api.onnorokomsms.com/sendsms.asmx?wsdl");
									$paramArray = array(
									 'userName'=>"01715840339",
									 'userPassword'=>"9226",
									 'mobileNumber'=> $mobile,
									 'smsText'=>$SMS,
									 'type'=>"1",
									 'maskName'=> "",
									 'campaignName'=>'',
									 );
									 $value = $soapClient->__call("OneToOne", array($paramArray));
								 } catch (dmException $e) {
								 // echo $e;
							}
			//end sms
		
		unset($email); 
		unset($_POST); 
	}
	

	
	if(isset($_POST['submit'])){
		if(!($date==$_POST['from_date'])){
			if(empty($_POST['confirm'])){
				$result6 = mysqli_query($con,"SELECT DISTINCT(sale_no),`p_id`,order_date,pharmacy,confirm FROM `sale_details` WHERE order_date>='$_POST[from_date]' and order_date<='$_POST[to_date]' order by `sale_no` asc");
			}else{
				$result6 = mysqli_query($con,"SELECT DISTINCT(sale_no),`p_id`,order_date,pharmacy,confirm FROM `sale_details` WHERE confirm='$_POST[confirm]' and order_date>='$_POST[from_date]' and order_date<='$_POST[to_date]' order by `sale_no` asc");
			}
		}else if(!empty($_POST['confirm'])){
			$result6 = mysqli_query($con,"SELECT DISTINCT(sale_no),`p_id`,order_date,pharmacy,confirm FROM `sale_details` WHERE confirm='$_POST[confirm]' order by `sale_no` asc");
			
		}
	}
	else
	{
		$result6 = mysqli_query($con,"SELECT DISTINCT(sale_no),`p_id`,order_date,pharmacy,confirm FROM`sale_details` WHERE order_date='$date' order by `sale_no` asc");
	}
?>
	
	<table align="center" width="800" border="0" >
		<tr>
			<td>#</td>
			<td>Date</td>
			<td>Order ID</td>
			<td>Client ID</td>
			<td>Name</td>
			<td>Mobile</td>
			<td>Pharmacy</td>	
			<td>Action</td>	
		</tr>
			
				<?php
				$j=1;
				while($row = mysqli_fetch_array($result6)){
					$p_id=$row['p_id'];
				$re = mysqli_query($con,"SELECT * FROM `patient_info` WHERE `p_id`='$p_id'");
					while($row1 = mysqli_fetch_array($re)){
					
					?>   
					<form action="" method="POST" >
						<input type="hidden" name="p_id" value="<?php echo $row['p_id']; ?>">
						<input type="hidden" name="sale_no" value="<?php echo $row['sale_no']; ?>">
						<input type="hidden" name="pharmacy" value="<?php echo $row['pharmacy']; ?>">
						
						<tr>
							<td><?php echo $j++; ?></td>
							<td><?php echo date("d-m-Y",strtotime($row['order_date'])); ?></td>
							<td align="center">
							<a href="<?php echo 'invoice_process.php?sale_no='.$row['sale_no'];?>" target="_blank"> <?php echo $row['sale_no'];?>
							</td>
							<td align="center"><?php echo $row['p_id']; ?></td>
							<td align="left">&nbsp;&nbsp;<?php echo $row1['p_name']; ?></td>
							<td align="center"><?php echo $row1['phone']; ?></td>
							<td align="left"><?php echo $row['pharmacy']; ?></td>
							<td align="center">
								<?php
						$check=$row['confirm'];
						if('Yes'==$check) {
							?><button class="btn btn-success" onClick="alert('This record was confirmed. No change after confirm record');">Confirmed</button><?php
							
							} 
							else {
								?><button class="btn btn-danger" name="yes" onClick="return confirm('Are you SURE, want to CONFIRM this record?');" type="submit">Confirm</button>
							<?php
							} 
					?> 
								<!--<input type="submit" class="myButton" name="yes" onclick="return confirm('Do you want to Confirm');"   value="CONFIRM" />-->
							</td>		
						</tr>
					</form>
					<?php
					
				}}
			?>
			
		
		</table>
	



       </div></div>
        <?php
		mysqli_close($con);
	include ("footer.php");
	?>
    </div>
</body>
</html>
