<div id="leftmenu">

<div class="menu_simple">

<?php
	include "config.php";
	$nav=$_GET['nav'];
	$result3 = mysqli_query($con,"SELECT * FROM member where username='$_SESSION[myusername]'");
	while($row = mysqli_fetch_array($result3))
		{
			if($row['type']=="ADMIN"){
				switch ($nav) {
					case 'order':
						echo "<ul>
								<li><a href='pharmacy.php'><span>Pharmacy</span></a></li>
								<li><a href='medicine.php'><span>Medicine</span></a></li>
								<li><a href='order_confrim.php'><span>Order</span></a></li>
							  </ul>";
						break;
					
					case 'reports':
						echo "<ul>
								
								
							  </ul>";
						break;
					
					 default:
						echo "<ul>
								<li>Welcome, <strong>".$_SESSION["myusername"]."</strong></li>
							  </ul>";
				}
			}
			else if($row['type']=="MANAGER"){
				switch ($nav) {
				case 'order':
					echo "<ul>
								
								
								
							  </ul>";
					break;
				
				case 'reports':
					echo "<ul>  
					            
						  </ul>";
					break;
				
				 default:
					echo "<ul>
							<li>Welcome, <strong>".$_SESSION["myusername"]."</strong></li>
						  </ul>";
				}
			}
			else {
					;
				}
		} 

	?>
  </div>

</div>
