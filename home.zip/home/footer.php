<div id="footer" >
  <div class="col-md-12" align="center">
    
      <div class="col-md-4"><img src="img/logo2.png" class="img-thumbnail" alt="al" width="50" height="50" /><strong>  &copy; AnandaSoftBD, All rights reserved.</strong></div>
	  <div class="col-md-4"> </div>
      <div class="col-md-4">Develop by- <a href="http://anandasoftbd.com" target="_blank"> AnandaSoftBD</a>, MYMENSINGH <br>Mob: 01715104528</div>
 
  </div>
</div>