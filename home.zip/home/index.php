<?php

session_start();
if(!isset( $_SESSION['myusername'] ))
{
    header("location:login.php");
}

?>
<?php
ob_start();
require_once "config.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>.::AnandasoftBD::.</title> 
</head>
<body>
    <div id="wrapper">
       <?php
	include "head.php";
	include "leftmenu.php";
	?>
        <div id="content">
			<div class="icon">
		
		   <div class="hlink"><a href="order_confrim.php"><img src="img/report.png"><br><p>Order</p></a></div>
		   
			</div>
		
		   
		</div>
		   
		   
      <?php
	include "footer.php";
	?> </div>


	
</body>
</html>
