<?php
error_reporting(E_ERROR);
$date = date('Y-m-d', time());
$host="localhost";
$user="borodakt";
$password="rY5N6H7n3[;bDc";
$db="borodakt_medicine";
$con = mysqli_connect($host,$user,$password,$db);
if (!$con)
  {
  die('Could not connect: ' . mysqli_error($con));
  }


ini_set('max_execution_time', 0);
?>