<?PHP
session_start();
ob_start();
include("config.php");
 

$myusername = mysqli_real_escape_string($con,$_POST['myusername']);
$mypassword= mysqli_real_escape_string($con,$_POST['mypassword']);
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);

 
$query = "select * from member where username='$myusername' and password='$mypassword'";
 
$res = mysqli_query($con,$query);
 
$rows = mysqli_num_rows($res);
 
if($rows==1)
{
$_SESSION['myusername'] = $myusername;
$_SESSION['mypassword'] = $mypassword;
header("location:index.php");
}
else {

echo '<script type="text/javascript">alert("You Enter wrong user name and password. Please retry.");window.location=\'login.php\';</script>';
ob_end_flush();
}
?>

<?php 
include ("footer.php");
?>